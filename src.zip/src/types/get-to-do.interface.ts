// interface: get to do interface //
export default interface GetToDo {
    id: number;
    userId: string;
    goal: string;
    isChecked: boolean;
    priority: number;
}