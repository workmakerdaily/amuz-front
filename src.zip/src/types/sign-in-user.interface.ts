export default interface SignInUser {
    userId: string;
    userName: string;
    password: string;
}