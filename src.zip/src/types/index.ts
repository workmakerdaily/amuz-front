import GetToDo from "./get-to-do.interface";
import SignInUser from "./sign-in-user.interface";

export type {
    GetToDo,
    SignInUser,
}