// interface: 로그인 Request Body Dto //
export default interface SignInRequestDto {
    userId: string;
    password: string;
}