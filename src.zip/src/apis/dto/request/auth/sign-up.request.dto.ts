// interface: 회원 가입 Request Body Dto //
export default interface SignUpRequestDto {
    userId: string;
    userName: string;
    password: string;
}