// interface: Post To Do Request Dto //
export default interface PostToDoRequestDto {
    goal: string;
}