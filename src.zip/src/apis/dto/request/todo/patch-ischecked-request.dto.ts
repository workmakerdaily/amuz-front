// interface: Patch IsChecked Request Dto //
export default interface PatchIsCheckedRequestDto {
    isChecked: boolean;
}